describe('getAllProjects', () => {
  it('returns projects', () => {
    const expected = 3;
    const actual = help.sum(1, 2);
    expect(actual).toBe(expected); // .toBe() looks for strict equality!
  });
}); 